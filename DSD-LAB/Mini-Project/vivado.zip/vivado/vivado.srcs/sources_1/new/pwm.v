`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 21.10.2026 20:41:10
// Design Name: 
// Module Name: pwm
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module pwm(
        input pwm_mclk,
        input [15:0] pwm_din,
        output reg pwm_out = 1'b0
    );

reg [31:0] count = 0;
reg [11:0] dat = 0;
reg [31:0] interval = 0;

always @ (posedge pwm_mclk) begin
    if (count == 0) begin
        dat = pwm_din [15:4];
        pwm_out = 1'b1;
        interval = 50000 + ((190000 * dat) / 4095);
    end else if (count == interval) begin
        pwm_out = 1'b0;
    end
    
    if (count == 1999999) begin
        count = 0;
    end else begin
        count = count + 1;
    end
end

endmodule
